# Descripción
Este módulo es muy básico y sirve para probar Pipy.
Permite hacer operaciones básicas como sumar, restar, multiplicar y dividir entre dos numeros.
